
public class AssignVariables {
    public static void main(String[] args) {

        byte byteValue = 127;
        short shortValue = 32767;
        int intValue = 2000000000;
        long longValue = 919827112351L;
        char charValue = 'c';
        boolean boolValue = false;
        float floatValue = 0.5f;
        double doubleValue = 0.1234567891011;
        String stringValue = "Palo Alto, CA";

        byte testValue = (byte) 32768;
        System.out.println(testValue);
    }
}
